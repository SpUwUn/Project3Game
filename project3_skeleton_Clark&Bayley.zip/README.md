# Pearl Street Date

You're bringing your significant other to pearl street, and you have a set amount of money to spend on the date
certain activities will cost specific amounts of money, and contribute specific amounts to the quality of the date.
After all the money has been spent, the date ends and you get a score based on the quality of the date.

(Recitation brainstorming classes)
Player Class - class that manages budget and tally of choices


Game Class - handles initialization and stuff


Building Class - event class that handles interactions with stores, restaurants, etc, giving the player options (costing money) that either contribute positively or negatively to the date

    will be stored in an array in main and all references to locations will be references to this array


NPC Class - small class that handles NPC interactions, which can give the player insights on what options are good/bad
