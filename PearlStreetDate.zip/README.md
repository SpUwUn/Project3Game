# Pearl Street Date


------------------------
HOW TO COMPILE AND RUN
------------------------
Compile: g++ -std=c++17 pearlStreetDate.cpp location.cpp player.cpp npc.cpp map.cpp sigother.cpp -o 
psd
Run: ./psd
------------------------
DEPENDENCIES
------------------------
location.h, map.h, npc.h, player.h, and sigOther.h must be in the same directory as the cpp 
files in order to compile.
------------------------
SUBMISSION INFORMATION
------------------------
CSCI1300 Spring 2022 Project 3
Author: Taylor Clark and Jonathan Bayley
Recitation: 104 - Daniel Torres
Date: April 21, 2022
------------------------
ABOUT THIS PROJECT
------------------------

You're bringing your significant other to pearl street, and you've got one night to have the best date ever.
Depending on how you make your choices, you will either increse or decrease the quality of your date. Choose wisely!
Once you've visited all of the locations, you end the game and get a final score.

